<?php 
$servername ="localhost";
$username = "root";
$password = "";
$dbname = "loan";

$conn = new mysqli($servername, $username, $password, $dbname);
 ?>