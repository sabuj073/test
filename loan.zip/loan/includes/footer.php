<footer id="sticky-footer" class="bg-dark text-white-50">
    <div class=" text-center">
      <small>Developed by &copy; <a href="https://www.iftisoft.com/">Iftisoft Inc</a></small>
    </div>
  </footer>

 <style type="text/css">
 	.bg_color{
  background-color: red;
}
#sticky-footer {
  flex-shrink: none;
  bottom: 0;
}
.bg-dark{
  background-color: black;
  color: white;
  margin: 0;
  padding-top: 5px;
  padding-bottom: 5px;
  top: 0;
  bottom: 0;
  font-size: 25px;
}
a{
  text-decoration: none;
  color: #FF6357;
}
 </style>