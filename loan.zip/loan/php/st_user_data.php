<?php 
	
	require "config.php";
	$userid = $_POST['userid'];
	$name = $_POST['name'];
	$email = $_POST['mail'];
	$number = $_POST['number'];
	$al_num = $_POST['al_num1'].' - '.$_POST['al_num2'];

	mysqli_query($con,"INSERT into user_loan_data VALUES(null,'{$userid}','{$name}','{$email}','{$number}','{$al_num}')");

 ?>