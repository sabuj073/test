<!DOCTYPE html>
<html lang="en">
<head>
  <title>Loan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

  <nav class="" style="background-color: black;">
    <div class="container-fluid">
      <div class="navbar-header">
        <a href="index.php">
        <img class="nav" src="../image/logo.png" width="100" style="margin: 5px;"> <font style="color: white;text-decoration: none;font-size: 25px;">Loan</font>
        </a>
      </div>
    </div>
  </nav>
  <?php require 'sidebar.php'; ?>



